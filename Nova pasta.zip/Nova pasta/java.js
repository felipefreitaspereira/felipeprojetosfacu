var obj = {
    "nome": "felipe", temponaCidade: 10, nome "Fulano",
    data: Date.now()
};
obj.getDATA = funcion() {
    return new Date(this.dat)
};

function Pessoa(nome, cidade, tempoNaCidade, anoNascim) {
    var pessoa = {
        "nome": nome,
        cidade: cidade,
        tempoNaCidade: tempoNaCidade,
        anoNascim: anoNascim,
        data: Date.now()
    };
    pessoa.getDATA = function () {
        return new Date(this.data);
    };
    pessoa.idade = function () {
        var dataAtual = New Date(Date.getFullYear(1987))
    };
    return pessoa;
}

var objfelipe = Pessoas("felipe", "Curitiba", 10);
var objfulano = Pessoas("fulano", "Curitiba", 50);



function Pessoa(nome, cidade, tempoNaCidade, anoNascim) { //corpo da função function name(params)
    var pessoa = {
        "nome": nome, cidade: cidade, tempoNaCidade: tempoNaCidade, anoNascim: anoNascim,
        data: Date.now()
    };
    pessoa.getDATA = function () {
        return new Date(this.data);
    };
    pessoa.idade = function () {
        var dataAtual = new Date(Date.now());
        return dataAtual.getFullYear() - this.anoNascim
    }
    return pessoa;
}

var objFelipe = Pessoa("Felipe", "Curitiba", 12, 1987);
var objFulano = Pessoa("Felipe", "Curitiba", 12, 2016);
objFelipe.idade();
objFulano.idade();
2
objFelipe.idade()
31